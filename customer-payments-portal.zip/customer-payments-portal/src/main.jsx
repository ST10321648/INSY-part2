import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom"; // <-- import React Router
import "./index.css";
import App from "./App.jsx";
import Payments from "./Payments.jsx"; // <-- import Payments page

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<App />} />          {/* Login page */}
        <Route path="/payments" element={<Payments />} />  {/* Payments page */}
      </Routes>
    </BrowserRouter>
  </StrictMode>
);
