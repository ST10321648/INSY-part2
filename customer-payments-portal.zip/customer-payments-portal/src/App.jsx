import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./App.css";

function App() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const navigate = useNavigate();

  // Regex validation functions
  const validateEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const validatePassword = (password) =>
    /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/.test(password); 
    // Minimum 8 characters, 1 letter, 1 number

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validation checks
    if (!validateEmail(email)) {
      setError("❌ Invalid email format.");
      return;
    }
    if (!validatePassword(password)) {
      setError(
        "❌ Password must be at least 8 characters, include 1 letter and 1 number."
      );
      return;
    }

    setError("");
    // Navigate to Payments page on successful login
    navigate("/payments");
  };

  return (
    <div className="container">
      <h1>Customer Payments Portal Login</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder="Enter Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Enter Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        {error && <p className="error">{error}</p>}
        <button type="submit" className="submit-btn">Login</button>
      </form>
    </div>
  );
}

export default App;
